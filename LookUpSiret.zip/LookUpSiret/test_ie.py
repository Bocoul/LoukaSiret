# -*- coding: utf-8 -*-
from ie import IExplore
import unittest

 
class test_IExplore(unittest.TestCase):   

    def test_create(self):
        ie= IExplore("")
        url = "www.google.frtyt"
        ie.create(url)
        assert url in ie.getWebBrowser().document.location.href  


test_IExplore()