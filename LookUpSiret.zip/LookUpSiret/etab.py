# -*- coding: utf-8 -*-
"""
Created on Mon Jul 13 01:51:12 2020
@author: C21373
"""
from ie import IExplore
import models
import sys

URL_SIRENE_ROOT = "http://sirene.fr/sirene/public/recherche"
URL_ETAB = ""


def readSiret(siren, dep):
    pass


# def navigateSiret():
#     ie= IExplore("")
#     if ie == None:
#         print("Echèc control internet explorer")
#         return None    
#     ie.readDocument(url, readInfosEtablissement)    
#     return tpl_siret


def HttpResquestString(paramsNew):
    PARAMS = {"__checkbox_recherche.excludeClosed":"true",
            "recherche.adresse": "",
            "recherche.captcha": "",
            "recherche.commune": "",
            "recherche.excludeClosed": "true",
            "recherche.raisonSociale":"",
            "recherche.sirenSiret":"" }

    for key in paramsNew:
        PARAMS[key] =  paramsNew[key]
    
    return ( "&".join([("{}={}".format(key, PARAMS[key])) for key in PARAMS]))

print(HttpResquestString({"recherche.commune":"rosny+sur+seine"}))

def readInfosEtablissement(doc):
    try:
        tpl_siret =((doc.all("prmId").value), 
                    (doc.all("voie").value),
                    (doc.all("codePostal").value),
                    (doc.all("commune").value),
                    (doc.all("codeINSEE").value))                        
    except:
        if (doc.locationUrl == url):
            tpl_siret =(siret, "etab inexistant", "", "", "", )
        else:
            tpl_siret = ()
            print("erreur sur le etab: " , siren )
    
    return tpl_siret

todolist = models.readMinus("pdl", "etab", 'code_postal,siren')
print("il reste {} à traiter".format(len(todolist)))
ie= IExplore(URL_SIRENE_ROOT)

# for tpl_row in todolist:
#     siren = tpl_row[5]
#     url = getUrl_sirene_fr()
#     URL_SIRENE_ROOT + URL_ETAB.replace('[etab]',"{:>014}".format(siren))
#     tpl_siret = ie.readDocument(url, readInfosEtablissement)
#     tpl_siretsiren = tpl_siret + (tpl_row[1],)    
#     header = ("siret","voie","code_postal","commune","code_insee","siren" )
#     if len(tpl_siretsiren)  == len(header):
#        try:
#            models.write("etab", header, tpl_siretsiren)
#        except:
#            print("Unexpected error:", sys.exc_info())
#           exit()

          
               
    
    # print(tpl_siretsiren)
