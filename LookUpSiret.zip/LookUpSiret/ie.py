# -*- coding: utf-8 -*-



# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 00:19:39 2019
@author: c21373

"""
from win32com.client import dynamic




def loadwait(oIE):
    while (True):
        if (not (oIE.busy) and (oIE.readyState == 4)):    
            return True    

class shell(object,):

    def __init__(self):
        try:
            o_shell = dynamic.Dispatch("shell.Application.1")
        except:
            print("Une erreur shell lors de la recherche d'internet Explorer") 
            raise



class IExplore(object,): 
    
    def __init__(self,  location):
        self.__location__ = location
        self.__webBrowser__ = None

        self.setShell()
        if self.__location__ == "":
            return

        try:
            self.attach()
        except:
            self.create(self.__location__)
    


    def setShell(self, classname = "shell.Application.1"):
        try:
            self.__shell__ = dynamic.Dispatch(classname)
        except:
            print("Une erreur shell lors de la recherche d'internet Explorer") 
            raise


    def create(self, location = "", visible = True):
        if location != "":
            self.__location__ = location
        
        
        cmd = '"C:\Program Files\Internet Explorer\iexplore.exe" {}'.format(self.__location__ )
        print(cmd)
        self.__webBrowser__ = self.setShell("InternetExplorer.Application")
        print(type(self.__webBrowser__ ))
        self.__webBrowser__.Visible = visible
        return self.__webBrowser__

#    @staticmethod
    def attach(self):
        print("Location: '{}'".format(self.__location__))  
        for oIE in self.__shell__.windows():
            loadwait(oIE)           
            try:
                
                print("Location: '{}'".format(oIE.document.location.hostname))               
                
                if (oIE.document.location.href in self.__location__):
                    self.__webBrowser__ = oIE
                    return self.__webBrowser__

            except:
                pass
        raise Exception("aucune instance trouvée")


    def getWebBrowser(self):
        return self.__webBrowser__


    def load(self, s_url, callBack=None ):
        self.__webBrowser__.navigate(s_url)
        loadwait(self.__webBrowser__)

        if (callBack != None):
            return callback(self.__webBrowser__.document)


    def readDocument(self, url, onload, onError):
        try:
            self.doc = self.__webBrowser__.document
            return self.doc
        except:
            print("erreur ie_load")
            return None
        
        
    def getDocument(self):        
        try:
            self.doc = self.__webBrowser__.document
            return self.doc
        except:
            print("erreur ie_load")
            return None
    

    def getBodyScreen(self):
        return self.getActiveFrameDocument().body
    

    def getActiveFrameDocument(self):
        return self.getActiveFrame().contentWindow.document


    def getFrames(self, i_numberFields = 5):        
        o_collection = []
        
#        o_collection = self.frame_sweview.Frames
#        print("nombre de frames: {}".format(o_collection.length))
        for obj in self.getFrame_sweview().document.getElementsByTagname("frame"):
            
           print("tous - nom: {}   -- domcomplet : {} -- connectEnd : {}".format(obj.name,  obj.contentWindow.performance.timing.Domcomplete ,  obj.contentWindow.performance.timing.connectEnd))
           
           print(self.getframe_swethreadbar())
           if  len(querySelector(obj.contentWindow.document.body, "object[tabindex>-1]")) > i_numberFields:
               print("-------- nom: {}   -- domcomplet : {} -- connectEnd : {}".format(obj.name,  obj.contentWindow.performance.timing.connectEnd,  obj.contentWindow.performance.timing.connectEnd  ))
               o_collection.append(obj)
        print("o_collection.length : {}".format(len(o_collection)))
        return o_collection


#        return [obj for obj in o_collection if (len(querySelector(obj.window.document.body, "object[tabIndex!=-1]")) > i_numberFields)]
       
    def getActiveFrame(self):
        self._active_frame = self.getFrames()
        return self._active_frame[0]
#        return self.frame_sweview.Frames("_svf0")
    

    def getInputsObjects(self):
        pass
    

    def getLinkAnchor(self):
        pass

    
def querySelector(o_parent_node,  s_selector_txt = "."):
    a_jetons  = s_selector_txt.split("[")
    
    o_collection = list()

    if (len(a_jetons[0]) == 0):
        o_collection = o_parent_node.all
          
    elif  a_jetons[0].startswith('.'):
        s_classname = (a_jetons[0])[1:]
        o_collection = ___getElementsByAttribute___(o_parent_node.all, "classname=={}".format(s_classname))

    elif (a_jetons[0].startswith('#')):
        s_Id = (a_jetons[0])[1:]  
        o_collection = ___getElementsByAttribute___(o_parent_node.all, "id=={}".format(s_Id))

    else:        
        s_tagname = a_jetons[0]  
        o_collection = o_parent_node.getElementsByTagname(s_tagname)
      
    if len(a_jetons) == 1:
        return o_collection
  
    return ___getElementsByAttribute___(o_collection, a_jetons[1].replace(']', ''))
 
   
def ___getElementsByAttribute___(o_collection, s_attr):
    try:
        if s_attr.find("==") > -1:
            a_attr = s_attr.lower().split("==")
            return [obj for obj in o_collection if str(obj.getattribute(a_attr[0])).lower() == str(a_attr[1])]
        elif s_attr.find("!=") > -1:
            a_attr = s_attr.lower().split("!=")
            return [obj for obj in o_collection if str(obj.getattribute(a_attr[0])).lower() != str(a_attr[1])]
        elif s_attr.find(">") > -1:
            a_attr = s_attr.lower().split(">")
            return [obj for obj in o_collection if str(obj.getattribute(a_attr[0])).lower() > str(a_attr[1])] 
        elif s_attr.find("<") > -1:
            a_attr = s_attr.lower().split("<")
            return [obj for obj in o_collection if str(obj.getattribute(a_attr[0])).lower() < str(a_attr[1])] 
    except:
        print("erreur recherche  par attribut")
        return []



def ___setInputValue(o_input, s_value = "@click"):
    try:
        if o_input.tagname != "input":
            raise( "error  dom type ")
        if (o_input.type == 'radio'):
            o_input.click()
        else:
            o_input.value = s_value
    except:
        print('Erreur input')



URL_SIRENE_ROOT = "http://sirene.fr/sirene/public/recherche"
ie= IExplore(URL_SIRENE_ROOT)